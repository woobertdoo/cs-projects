#ifndef TESTSCANNER_H
#define TESTSCANNER_H

#include <stdio.h>

void testScanner(const char* fileName);

#endif
